/* MULTITHREADING BookingClient.java
 * EE422C Project 6 submission by
 * Replace <...> with your actual data.
 * Sylvia Vu
 * sav987
 * 16330
 * Slip days used: <1>
 * Spring 2020
 */
package assignment6;

import assignment6.Theater.*;

import java.util.*;
import java.lang.Thread;

public class BookingClient {

    public Theater theater;
    public Map<String, Integer> boxOffice;      // stores each box office and how many clients are in line
    public List<String> offices = new ArrayList<>();    // stores the name of each box office
    public List<Integer> clients = new ArrayList<Integer>();    // stores all clientID's
    public int totalClients;                            // stores how many people are at the theater that night
    public boolean isRunning = false;

    /**
     * @param office  maps box office id to number of customers in line
     * @param theater the theater where the show is playing
     */
    public BookingClient(Map<String, Integer> office, Theater theater) {

        this.theater = theater;
        this.boxOffice = office;

        for(String boxNum : boxOffice.keySet()){    // establishes list of each box office at the theater
            offices.add(boxNum);
        }
    }

    /**
     * Starts the box office simulation by creating (and starting) threads
     * for each box office to sell tickets for the given theater
     *
     * @return list of threads used in the simulation,
     * should have as many threads as there are box offices
     */
    public List<Thread> simulate() {

        List<Thread> threads = new LinkedList<>();

        for(int i=0; i<boxOffice.size(); i++){
            String boxNum = offices.get(i);     // retrieve the box office we are working with
            totalClients += boxOffice.get(boxNum);      // line by line, find out how many people are at the theater
            Thread t = new Thread() {

                @Override
                public void run() {
                    int clientsInLine = boxOffice.get(boxNum);        // retrieve the number of people in line at this box office
                        while (clientsInLine > 0) {                      // loop as long as there are still people in line
                            synchronized (theater.openSeats) {
                                Seat nextBest = theater.bestAvailableSeat();    // before we even identify the next customer we want to SECURE THE SEAT

                                int clientID = getRandomID(totalClients + 1);   // generate a random clientID based on how many people are at the theater

                                if(!clients.isEmpty()) {
                                    while (clients.contains(clientID)) {              // Make sure that there are no clientID duplicates
                                        clientID = getRandomID(totalClients + 1);
                                    }
                                }

                                clients.add(clientID);           // once a unique ID has been found, add it to the clients list so it can't be duplicated
                                theater.printTicket(boxNum, nextBest, clientID);        // yay! Our client has secured their seat and they can receive their ticket
                                boxOffice.replace(boxNum, clientsInLine, clientsInLine-1);      // there is now one less person in line
                                clientsInLine--;        // update # of people in line
                            }

                            try {
                                Thread.sleep(theater.getPrintDelay());
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                };

            threads.add(t);     // account for this thread
            t.start();          // begin this thread

        }
        return threads;
    }

    private int getRandomID(int totalClients){
        Random rand = new Random();
        return rand.nextInt(totalClients);
    }

    public static void main(String[] args) {
        Map<String, Integer> boxOffices = new HashMap<String, Integer>();

        boxOffices.put("BX1", 500);       // establish and populate box offices
        boxOffices.put("BX2", 350);
        boxOffices.put("BX3", 400);
        boxOffices.put("BX4", 500);

        Theater mainTheater = new Theater(100, 1, "Nacho Libre");
        BookingClient booking = new BookingClient(boxOffices, mainTheater);
        List<Thread> threadList = booking.simulate();

        for(int i=0; i<mainTheater.getTransactionLog().size(); i++){
            System.out.println(mainTheater.getTransactionLog().get(i));
        }

    }
}
